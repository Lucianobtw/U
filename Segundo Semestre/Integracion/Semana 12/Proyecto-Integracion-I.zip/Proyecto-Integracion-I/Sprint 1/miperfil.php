<?php
session_start();

$varsesion = $_SESSION['usuario'];
//si la sesion sesion esta vacia no tiene autorizacion y cierra todo
if ($varsesion == null || $varsesion = '') {
	echo 'No tiene autorizacion';
	die();
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="icon" href="./img/favlogo.png">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="./CSS/MiPerfil.css">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
	<title>Mi perfil</title>
</head>

<body>
	<section class="perfil" id="">
		<div class="top">
			<h1>Mi Perfil</h1>
		</div>

		<div class="mid">
			<?php
			include_once("perfilConsulta.php");
			echo "<label for='uname'><b>Nombre de Usuario: " . $_SESSION['usuario'] . "</b></label>";
			echo '<label for="rut"><b>RUT: ' . $fila["Rut"] . '</b></label>';
			echo '<label for="email"><b>Correo electrónico: ' . $fila["email"] . '</b></label>';
			mysqli_close($conexion);
			?>
		</div>
		<div class="bottom">
			<a href="./home.php">Volver al Home</a>
		</div>
	</section>
</body>

</html>