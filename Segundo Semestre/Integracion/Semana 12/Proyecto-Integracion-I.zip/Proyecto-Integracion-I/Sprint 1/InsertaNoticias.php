<?php

/* Enlaza el archivo config.php */
/* Contiene la información relacionada a la DB */

include_once './config.php';

/* se obtienen los valores mediante método post del formulario html */


$conn = new mysqli($servername, $username, $password, $dbname);

/* chequea si la conexion falló, si es así mostrará el error. */

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$seccion = $_POST['f-seccion'];
$date = date("Y-m-d");
$titulo = $_POST['f-titulo'];
$url = $_POST['f-url'];
$autor = $_POST['f-autor'];
$descripcion = $_POST['f-desc'];


//Insercion a la base de datos mediante una consulta sql
$sql = "INSERT INTO `Noticia`(`ID_Seccion`, `Date`, `Titulo`, `url`, `Autor`, `Cuerpo`) VALUES 
    ('$seccion','$date','$titulo','$url','$autor','$descripcion')";

/* Se ejecuta el procedimiento almacenado */
$result = $conn->query($sql);

$response = array();

if ($result) {
    $response['success'] = "Mensaje enviado correctamente";
    exit(json_encode($response));
} else {
    $response['error'] = "error" . $conn->error;
    exit(json_encode($response));
}

/* Se cierra la conexion */
$conn->close();
