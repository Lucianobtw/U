<?php

//inicio sesion
error_reporting(1);

$varsesion = $_SESSION['usuario'];
//conectar a la base de datos
include_once("config.php");

$conexion = mysqli_connect($servername, $username, $password, $dbname);
//
$consulta = "SELECT Rut, Username, email FROM Usuario WHERE Username =  '$varsesion'  ";
//ejecutar la consulta 
//primero le indico la base de datos
$resultado = mysqli_query($conexion, $consulta);

//pongo en un arreglo el resultado
$fila = mysqli_fetch_array($resultado);

    //echo json_encode($fila);
