<?php
session_start();

$varsesion = $_SESSION['usuario'];
//si la sesion sesion esta vacia no tiene autorizacion y cierra todo
if ($varsesion == null || $varsesion = '') {
  echo 'No tiene autorizacion';
  die();
}
?>


<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Portal - Leyes</title>
  <link rel="icon" href="./img/favlogo.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
  <meta name="viewport" content="width=device-widht, initial-scale=1">
  <link rel="stylesheet" href="./CSS/header.css">
  <link rel="stylesheet" href="./CSS/sections-body.css">
  <link rel="stylesheet" href="./CSS/footer.css">
</head>

<body id="ley">
  <header class="header">

    <nav class="nav">

      <ul class="navlogo">

        <li><img src="./img/logo.png" alt=""></li>

      </ul>

      <ul class="nav-buttons">

        <li class="nav-button" id="admin"><a href="./admin.php">Administrar</a></li>
        <li class="nav-button"><a href="./home.php">Universidad</a></li>
        <li class="nav-button"><a href="./ingenieria.php">Ingeniería</a></li>
        <li class="nav-button"><a href="./pedagogia.php">Pedagogía</a></li>
        <li class="nav-button"><a href="./leyes.php">Leyes</a></li>
        <li class="nav-button"><a href="./miperfil.php">Mi perfil</a></li>
        <li class="nav-button"><a href="index.html">Cerrar sesión</a></li>

      </ul>

    </nav>

  </header>

  <main class="container">

    <h1 class="UCT" id="Titulo">Universidad Católica de Temuco</h1>
    <hr><br>

    <article class="article" id="article4">

    </article>

  </main>

  <footer class="footer">

    <nav class="footernav">

      <ul class="footer-text">

        <li>Portal UCT</li>
        <li>Copyright 2022</li>

      </ul>

      <ul class="links">

        <li><a href="./nosotros.html">Nosotros</a></li>
        <li><a href="./contacto.html">Contacto</a></li>

      </ul>

      <ul class="redes">

        <li><a href="https://web.facebook.com/canaluctemuco/?_rdc=1&_rdr" target="_blank" title="" class="facebook"><img src="./img/facebook.png" alt=""></a></li>
        <li><a href="https://www.instagram.com/uctemuco/?hl=es-la" target="_blank" class="instagram"><img src="./img/instagram.png" alt=""></a></li>
        <li><a href="https://www.twitter.com" target="_blank" class="youtube"><img src="./img/twitter.png" alt=""></a>
        </li>

      </ul>

    </nav>

  </footer>
  <script src="./Javascript/VisualizarNoticias.js"></script>
</body>

</html>