<?php
//inicio sesion
session_start();
error_reporting(1);
// reciviendo del campo usuario y lo almaceno el 
//variable $usuario y $clave del campo psw
$usuario = $_POST['uname'];
$clave = $_POST['psw'];

$_SESSION['usuario'] = $usuario;


//conectar a la base de datos
include_once("config.php");

$conexion = mysqli_connect($servername, $username, $password, $dbname);
//
$consulta = "SELECT * FROM Usuario WHERE Username = '$usuario' AND Contrasena = '$clave'";
//ejecutar la consulta 
//primero le indico la base de datos
$resultado = mysqli_query($conexion, $consulta);
$fila = mysqli_fetch_object($resultado);

$_SESSION['admin'] = $fila->Admin;

$filas = mysqli_num_rows($resultado);
if ($filas > 0) {
    header("location:home.php");
} else {
    echo "Error en la autentificacion";
}
//libere el espacio en memoria de la base de datos
mysqli_free_result($resultado);
//para dejar de conectarse a la base de datos 
mysqli_close($conexion);
