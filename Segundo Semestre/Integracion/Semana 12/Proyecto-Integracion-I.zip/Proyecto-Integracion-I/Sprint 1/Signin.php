<?php

$rut = $_POST['rut'];
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$edad = $_POST['edad'];
$email = $_POST['email'];
$usuario = $_POST['usuario'];
$psw = $_POST['psw'];

include_once 'config.php';

$link = new mysqli($servername, $username, $password, $dbname);


//compruebo que todos los datos estan llenos 

//fetch recive en formato JSON  

if ($rut === '' || $nombre === '' || $apellido === '' || $edad === '' || $email === '' || $usuario === '' || $psw === '') {
    echo json_encode('llena todos los campos');
} else {
    $tildes = $link->query("SET NAMES 'utf8'"); //Para que se inserten las tildes correctamente (por precaucion)

    mysqli_query($link, "INSERT INTO Usuario(Rut, Nombre, Primer_Apellido, Edad, Username, Contrasena, `Admin`, email, Estado)  VALUES ('$rut', '$nombre', '$apellido', '$edad', '$usuario', '$psw', '0', '$email', null)");

    $err = mysqli_error($link); //error

    echo json_encode('¿mensaje de error?: ' . $err);
}

mysqli_close($link); // Cerramos la conexion con la base de datos
