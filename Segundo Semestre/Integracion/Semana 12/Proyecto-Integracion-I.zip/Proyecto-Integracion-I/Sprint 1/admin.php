<?php
session_start();

$varsesion = $_SESSION['usuario'];
$admin = $_SESSION['admin'];
$vacio = $varsesion == null || $varsesion == '';
//si la sesion sesion esta vacia no tiene autorizacion y cierra todo
if ($vacio || $admin === '0') {
    echo 'No tiene autorizacion';
    die();
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Portal - Administrador</title>
    <link rel="icon" href="./img/favlogo.png" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
    <meta name="viewport" content="width=device-widht, initial-scale=1" />
    <link rel="stylesheet" href="./CSS/header.css" />
    <link rel="stylesheet" href="./CSS/Admin/grid.css" />
    <link rel="stylesheet" href="./CSS/Admin/admin.css" />
    <link rel="stylesheet" href="./CSS/footer.css" />
</head>

<body>
    <header class="header">
        <nav class="nav">
            <ul class="navlogo">
                <li><img src="./img/logo.png" alt="" /></li>
            </ul>

            <ul class="nav-buttons">
                <li class="nav-button" id="admin"><a href="./admin.php">Administrar</a></li>
                <li class="nav-button"><a href="./home.php">Universidad</a></li>
                <li class="nav-button"><a href="./ingenieria.php">Ingeniería</a></li>
                <li class="nav-button"><a href="./pedagogia.php">Pedagogía</a></li>
                <li class="nav-button"><a href="./leyes.php">Leyes</a></li>
                <li class="nav-button"><a href="./miperfil.php">Mi perfil</a></li>
                <li class="nav-button"><a href="./cerrar_sesion.php">Cerrar sesión</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <h1 class="UCT" id="Titulo">Administrar Portal de Noticias</h1>
        <hr /><br />

        <article class="article">
            <section class="menu">
                <nav class="nav-sections">
                    <ul class="ul">
                        <li class="section-buttons"><button id="b-crear">Crear Noticia</button></li>
                        <li class="section-buttons"><button id="b-editar">Editar Noticia</button></li>
                    </ul>
                </nav>
            </section>

            <section class="p-left" id="p-left">
                <h2>Publicar Noticia</h2>
                <form class="p-formulario" id="p-formulario" method="post">
                    <input id="titulo" name="f-titulo" type="text" class="p-input" placeholder="Titulo de la noticia" />
                    <input id="pre-t" type="button" class="b-pre" value="previzualizar" onclick="pretitle()" />
                    <input id="url" name="f-url" type="text" class="p-input" placeholder="Ruta / URL de la imagen" />
                    <input id="pre-i" type="button" class="b-pre" value="previzualizar" onclick="img()" />
                    <input id="autor" type="text" name="f-autor" class="p-input" placeholder="Autor de la noticia" />
                    <input id="pre-a" type="button" class="b-pre" value="previzualizar" onclick="preautor()" />
                    <input id="descripcion" type="" class="p-input" name="f-desc" placeholder="Descripción" />
                    <input id="pre-d" type="button" class="b-pre" value="previzualizar" onclick="predescripcion()" />

                    <select name="f-seccion" id="seccion" class="select-seccion">
                        <option value="1">Universidad</option>
                        <option value="2">Ingeniería</option>
                        <option value="3">Pedagogía</option>
                        <option value="4">Leyes</option>
                    </select>

                    <div class="p-botones-master">
                        <input id="publicar" class="p-publicar" type="submit" value="Publicar" />
                        <input id="cancelar" class="p-eliminar" type="submit" value="Cancelar Publicación" />
                    </div>
                </form>
            </section>

            <section class="p-right" id="p-right">
                <h2 class="Postitle" id="pre-titulo"></h2>

                <div class="div-img-notice">
                    <img src="" width="400" alt="" id="pre-img" />
                </div>

                <div>
                    <h4 class="author" id="pre-autor"></h4>
                    <p class="destxt" id="pre-desc"></p>
                </div>
            </section>

            <section class="e-left" id="e-left">
                <div class="e-menu">
                    <nav class="e-nav-sections">
                        <ul class="e-ul">
                            <li class="section-buttons"><button id="universidad">Universidad</button></li>
                            <li class="section-buttons"><button id="ingenieria">Ingenieria</button></li>
                            <li class="section-buttons"><button id="pedagogia">Pedagogia</button></li>
                            <li class="section-buttons"><button id="leyes">Leyes</button></li>
                        </ul>
                    </nav>
                </div>

                <div class="ncont" id="ucont"></div>
                <div class="ncont" id="icont"></div>
                <div class="ncont" id="pcont"></div>
                <div class="ncont" id="lcont"></div>
            </section>

            <section class="e-right" id="e-right">
                <form class="e-form" id="e-form" method="post">
                    <label for="id">ID Noticia (No editable)</label>
                    <input type="text" id="e-id" name="e-id" class="e-input" />
                    <label for="titulo">Titulo</label>
                    <input type="text" class="e-input" id="e-titulo" name="e-titulo" />
                    <label for="">URL Imagen</label>
                    <input type="text" class="e-input" id="e-img" name="e-url" />
                    <label for="autor">Autor</label>
                    <input type="text" class="e-input" id="e-autor" name="e-autor" />
                    <label for="descripcion">Descripción</label>
                    <input type="text" id="e-desc" class="e-input" name="e-desc" />
                </form>

                <div class="e-botones-master">
                    <input id="e-update" class="e-publicar" type="submit" value="Editar Noticia" />
                    <input id="e-delete" class="e-eliminar" type="submit" value="Eliminar Noticia" />
                </div>
            </section>
        </article>
    </main>

    <footer class="footer">
        <nav class="footernav">
            <ul class="footer-text">
                <li>Portal UCT</li>
                <li>Copyright 2022</li>
            </ul>

            <ul class="links">
                <li><a href="./nosotros.html">Nosotros</a></li>
                <li><a href="./contacto.html">Contacto</a></li>
            </ul>

            <ul class="redes">
                <li><a href="https://web.facebook.com/canaluctemuco/?_rdc=1&_rdr" target="_blank" title="" class="facebook"><img src="./img/facebook.png" alt="" /></a></li>
                <li><a href="https://www.instagram.com/uctemuco/?hl=es-la" target="_blank" class="instagram"><img src="./img/instagram.png" alt="" /></a></li>
                <li><a href="https://www.twitter.com" target="_blank" class="youtube"><img src="./img/twitter.png" alt="" /></a></li>
            </ul>
        </nav>
    </footer>
    <script src="./Javascript/EditarNoticias.js"></script>
    <script src="./Javascript/PublicarNoticias.js"></script>
</body>

</html>