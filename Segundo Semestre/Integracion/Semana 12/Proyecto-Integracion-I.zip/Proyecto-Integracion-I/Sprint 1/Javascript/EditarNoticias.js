"use strict";

/* ---------------- Variables DOM ------------------ */

/* ----- Contenedores de contenido de la pagina ---- */

let pleft = document.getElementById("p-left");
let pright = document.getElementById("p-right");
let eleft = document.getElementById("e-left");
let eright = document.getElementById("e-right");

/* ----------- Contenedores por seccion ------------- */

let ucont = document.getElementById("ucont");
let icont = document.getElementById("icont");
let pcont = document.getElementById("pcont");
let lcont = document.getElementById("lcont");

/* -------------- Botones por seccion --------------- */

const u = document.getElementById("universidad");
const i = document.getElementById("ingenieria");
const p = document.getElementById("pedagogia");
const l = document.getElementById("leyes");

/* -------------------------------------------------- */

/* Funciones que cambian de pestaña (Publicar y Editar) */

/* -- Botones para cambiar la funcion de la pagina --- */

let btncrear = document.getElementById("b-crear");
let btneditar = document.getElementById("b-editar");

btncrear.addEventListener("click", function () {
    eleft.style.display = "none";
    eright.style.display = "none";
    pleft.style.display = "block";
    pright.style.display = "block";
});

btneditar.addEventListener("click", function () {
    pleft.style.display = "none";
    pright.style.display = "none";
    eleft.style.display = "grid";
    eright.style.display = "block";
});

/* -------------------------------------------------- */

/* Funcion que muestra las noticias de cada seccion */

async function recibedatos() {
    const response = await fetch("./editar.php", {
        method: "POST",
    });

    const respuesta = await response.text();

    const obj = JSON.parse(respuesta);

    for (let i = 0; i < obj.length; i++) {
        let noticia = obj[i];

        /* -------------------------------------------------- */

        /*  Se Crean y se añaden los elementos de la noticia  */
        /*          en sus respectivos contenedores           */

        const div = document.createElement("div");
        div.classList.add("noticias");
        div.setAttribute("id", noticia.ID_Noticia);
        div.setAttribute("onclick", "editar(" + noticia.ID_Noticia + ")");

        const h2 = document.createElement("h2");
        const h3 = document.createElement("h3");
        const p = document.createElement("p");

        h2.innerHTML = `${noticia.Titulo}`;
        h3.innerHTML = `${noticia.Autor}`;
        p.innerHTML = `${noticia.Cuerpo}`;

        div.appendChild(h2);
        div.appendChild(h3);
        div.appendChild(p);

        /* -------------------------------------------------- */

        /*  Se añaden los contenedores a sus respectivas secciones  */

        /* i = 1 porque las secciones comienzan en 1 */
        /* Si la id de la noticia == 1 */
        /* Se añade esa noticia al contenedor determinado */
        /* segun el orden de la lista divs (indices de lista parten en 0) */
        /* por lo que se debe restar 1 para respetar el orden */

        let divs = [ucont, icont, pcont, lcont];

        for (let i = 1; i < 5; i++) {
            if (noticia.ID_Seccion == i) {
                divs[i - 1].appendChild(div);
                divs[i - 1].style.display = "none";
            }
        }
    }
}

/* -------------------------------------------------- */

/* Se activa la extraccion de contenido de la bd */

let divs = [ucont, icont, pcont, lcont]; /* Arreglo de contenedores segun seccion */
let sections = [u, i, p, l]; /* arreglo de botones por seccion */

/* Se recorre el arreglo sections y reconoce eventos click */
/* al detectar el evento se mostrará la informacion de la bd (Noticias) */
/* y se cambiará el display de el contenedor identificado por la iteración */
/* del arreglo divs a "grid" */

for (let i = 0; i < sections.length; i++) {
    sections[i].addEventListener("click", async function () {
        divs[i].innerHTML = "";
        await recibedatos();
        divs[i].style.display = "grid";
    });
}

/* ---- Funcion que se activa mediante "onclick" ----- */

/* Se encarga de enviar los datos de la noticia (ID) a editar */

/* Si la id de la noticia coincide con alguna de la bd */
/* Sus atributos se mostraran en en el formulatio lateral */

async function editar(id) {
    const response = await fetch("./editar.php", {
        method: "POST",
    });

    const respuesta = await response.text();
    const obj = JSON.parse(respuesta);

    for (let i = 0; i < obj.length; i++) {
        let noticia = obj[i];

        if (id == noticia.ID_Noticia) {
            document.getElementById("e-id").value = noticia.ID_Noticia;
            document.getElementById("e-titulo").value = noticia.Titulo;
            document.getElementById("e-img").value = noticia.url;
            document.getElementById("e-autor").value = noticia.Autor;
            document.getElementById("e-desc").value = noticia.Cuerpo;
        }
    }
}

/* ----  ----- */

let eform = document.getElementById("e-form");
let updbtn = document.getElementById("e-update");

async function Update(x) {
    const response = await fetch("./UpdateNoticias.php", {
        method: "POST",
        body: x,
    });

    const respuesta = await response.text();
}

updbtn.addEventListener("click", function (event) {
    let data = new FormData(eform);
    event.preventDefault();
    Update(data);
    eform.reset();
});
