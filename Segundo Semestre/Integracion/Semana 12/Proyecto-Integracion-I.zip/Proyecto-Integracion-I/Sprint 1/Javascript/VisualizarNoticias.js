async function recibedatos() {
    const response = await fetch("./editar.php", {
        method: "POST"
    });

    const respuesta = await response.text();

    const obj = JSON.parse(respuesta);
    var page = document.body.id
    for (let i = 0; i < obj.length; i++) {
        
        let noticia = obj[i];

        const section = document.createElement("section");
        const h2 = document.createElement("h2");
        const img = document.createElement("img");
        const div1 = document.createElement("div");
        const h4 = document.createElement("h4");
        const p1 = document.createElement("p");
        const form = document.createElement("form");
        const input = document.createElement("input");
        const div2 = document.createElement("div");
        const h3 = document.createElement("h3");
        const p2 = document.createElement("p");

        section.classList.add("noticia");
        h2.classList.add("Postitle");
        h4.classList.add("author");
        p1.classList.add("destxt");
        form.classList.add("form");
        div2.classList.add("comment-box");

        input.type = "text";
        input.placeholder = "Comenta!";

        p2.innerHTML = "Lorem ipsum dolor sit amet, ESTO ES UN COMENTARIO consectetur adipisicing elit. Beatae, dolorum?) = Lorem ipsum dolor sit amet";

        h2.innerHTML = `${noticia.Titulo}`;
        img.src = `${noticia.url}`;
        p1.innerHTML = `${noticia.Cuerpo}`;
        h3.innerHTML = `${noticia.Autor}`;

        div1.appendChild(h4);
        div1.appendChild(p1);
        form.appendChild(input);
        div2.appendChild(h3);
        div2.appendChild(p2);
        section.appendChild(h2);
        section.appendChild(h3);
        section.appendChild(img)
        section.appendChild(div1);
        section.appendChild(form);
        section.appendChild(div2);

        switch (page) {
            case 'uni':
                if (`${noticia.ID_Seccion}` == 1){
                    document.getElementById("article1").appendChild(section)
                } else break
            case 'ing':
                if (`${noticia.ID_Seccion}` == 2){
                    document.getElementById("article2").appendChild(section)
                } else break
            case 'ped':
                if (`${noticia.ID_Seccion}` == 3){
                    document.getElementById("article3").appendChild(section)
                } else break
            case 'ley':
                if (`${noticia.ID_Seccion}` == 4){
                    document.getElementById("article4").appendChild(section)
                } else break
        }

    }
}
recibedatos();