const formulario = document.getElementById("formulario");
//almaceno todos los imputs de mi formulario
//arreglo con todos los inputs dentro del id formulario
const inputs = document.querySelectorAll("#formulario input");

//expresiones regulares
//para que pueda validar los datos ingresados
const expresiones = {
    usuario: /^[a-zA-Z0-9\_\-]{4,16}$/, //letras,numeros,guion y guion_bajo (entre 4 a 16)
    correo: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/, //formato correo (hola@gmail.com)
    rut: /^\d{7,8}$/, // 7 a 8 numeros
    password: /^.{4,12}$/, //4 a 12 digitos cualquiera (admite caracteres especiales)
    //actualizados
    nombre: /^[a-zA-Z]+$/, //letras de la a  hasta la z mayuscula o minuscula
    apellido: /^[a-zA-Z]+$/, //letras de la a  hasta la z mayuscula o minuscula
    edad: /^\d{1,3}$/, //numeros 1 a 3 digitos
};
// ^: el emparejamiento se debe realizar desde el principio de la cadena.
// [A-Z]: cualquier carácter entre la A mayúscula y la Z mayúscula.
// {1,2}: uno o dos caracteres.
// \s: un espacio en blanco.
// \d: un dígito.
// {4}: cuatro dígitos.
// \s: un espacio en blanco.
// ([B-D]|[F-H]|[J-N]|[P-T]|[V-Z]): cualquier carácter entre la B mayúscula y la Z mayúscula, excepto las vocales.
// {3}: tres caracteres.
// $: el emparejamiento se debe realizar hasta el final de la cadena.

const campos = {
    usuario: false,
    correo: false,
    rut: false,
    password: false,
    //
    nombre: false,
    apellido: false,
    edad: false,
};

//comenzaremos a hacer comprobaciones sobre campos rellenados

//vamos a comprobar que un usuario escribe sobre algun campo
//y cuado es usuario hace click fuera del formulario

//e = evento
const validarFormulario = (e) => {
    //nombre del input sea rut,email,uname,psw,psw_conf ahora tambien nombre,apellido,edad
    switch (e.target.name) {
        case "rut":
            validarCampo(expresiones.rut, e.target, "rut");
            break;
        case "nombre":
            validarCampo(expresiones.nombre, e.target, "nombre");
            break;
        case "apellido":
            validarCampo(expresiones.apellido, e.target, "apellido");
            break;
        case "edad":
            validarCampo(expresiones.edad, e.target, "edad");
            break;
        case "email":
            validarCampo(expresiones.correo, e.target, "correo");
            break;
        case "usuario":
            validarCampo(expresiones.usuario, e.target, "usuario");
            break;
        case "psw":
            validarCampo(expresiones.password, e.target, "contraseña");
            //le indico que en todo momento las contraseñas deben se iguales
            validarPassword2();
            break;
        case "psw_conf":
            //comprobamos que se escribio la misma contraseña
            validarPassword2();
            break;
    }
};

// funcion para validar los diferentes campos
// toma como parametros la expresion a validar (usuario, correo, rut o clave),
//el contenido del input a traves de e.target ,es decir , evento
//y el campo (rut, correo, usuario, contraseña, confirmacion)
const validarCampo = (expresion, input, campo) => {
    //cumple expresion regular
    if (expresion.test(input.value)) {
        //cambie las comillas simples por backticks (acento invertido) ó (comillas de ejecucion)``(ALT GR + } Ó ALT + 96)``
        //backticks permiten a javascript usar plantillas de strings o template strings
        document.getElementById(`grupo__${campo}`).classList.remove("formulario__grupo-incorrecto");
        document.getElementById(`grupo__${campo}`).classList.add("formulario__grupo-correcto");
        //mensaje para validar el input ocultado
        document.querySelector(`#grupo__${campo} .mensaje__error`).classList.remove("mensaje__invocado");
        document.querySelector(`#grupo__${campo} .mensaje__error`).classList.add("mensaje__oculto");
        //modifico el icono de check
        document.querySelector(`#grupo__${campo} i`).classList.remove("fa-times-circle");
        document.querySelector(`#grupo__${campo} i`).classList.add("fa-check-circle");
        //permite (cuando todos los inputs esten correctos) enviar el formulario
        campos[campo] = true;
        //si no se cumple la expresion regular del nombre usuario
    } else {
        document.getElementById(`grupo__${campo}`).classList.add("formulario__grupo-incorrecto");
        document.getElementById(`grupo__${campo}`).classList.remove("formulario__grupo-correcto");
        // mensaje para validar el input
        document.querySelector(`#grupo__${campo} .mensaje__error`).classList.add("mensaje__invocado");
        document.querySelector(`#grupo__${campo} .mensaje__error`).classList.remove("mensaje__oculto");

        //modifico el icono cruz
        document.querySelector(`#grupo__${campo} i`).classList.remove("fa-check-circle");
        document.querySelector(`#grupo__${campo} i`).classList.add("fa-times-circle");
        //evita enviar el formulario
        campos[campo] = false;
    }
};

const validarPassword2 = () => {
    //accedemos a los 2 inputs de password
    const inputPassword1 = document.getElementById("password");
    const inputPassword2 = document.getElementById("password2");

    if (inputPassword1.value !== inputPassword2.value) {
        //son los que modifica cuando esta mal (en este caso cuando no se repitio correctamente la contraseña)
        document.getElementById(`grupo__confirme`).classList.add("formulario__grupo-incorrecto");
        document.getElementById(`grupo__confirme`).classList.remove("formulario__grupo-correcto");
        // mensaje para validar el input
        document.querySelector(`#grupo__confirme .mensaje__error`).classList.add("mensaje__invocado");
        document.querySelector(`#grupo__confirme .mensaje__error`).classList.remove("mensaje__oculto");

        //modifico el icono cruz
        document.querySelector(`#grupo__confirme i`).classList.remove("fa-check-circle");
        document.querySelector(`#grupo__confirme i`).classList.add("fa-times-circle");

        campos["password"] = false;
        //en caso de que sean iguales
    } else {
        document.getElementById(`grupo__confirme`).classList.remove("formulario__grupo-incorrecto");
        document.getElementById(`grupo__confirme`).classList.add("formulario__grupo-correcto");
        // mensaje para validar el input
        document.querySelector(`#grupo__confirme .mensaje__error`).classList.remove("mensaje__invocado");
        document.querySelector(`#grupo__confirme .mensaje__error`).classList.add("mensaje__oculto");

        //modifico el icono cruz
        document.querySelector(`#grupo__confirme i`).classList.add("fa-check-circle");
        document.querySelector(`#grupo__confirme i`).classList.remove("fa-times-circle");

        campos["password"] = true;
    }
};

//por cada input quiero que tengas un addEventListener()
inputs.forEach((input) => {
    //keyup = levantar tecla
    input.addEventListener("keyup", validarFormulario);
    //blur = teclear fuera del form
    input.addEventListener("blur", validarFormulario);
});

//escuchacha el evento de registrarse
// parametro e es el evento ('submit' o registrarse)
formulario.addEventListener("submit", (e) => {
    //evita que envie cualquier dato por defecto por el navegador
    e.preventDefault();

    //si todos los campos estan true (reseteame los campos)
    if (campos.usuario && campos.correo && campos.rut && campos.password && campos.nombre && campos.apellido && campos.edad) {
        //envio finalmente los datos a la base de datos

        //pasamos los datos del formulario
        var datos = new FormData(formulario);

        //enviamos por fetch a traves del methodo post los datos del formulario
        fetch("./Signin.php", {
            method: "POST",
            body: datos,
        })
            .then((res) => res.json())
            .then((data) => {
                console.log(data);
            });

        //advertencia de formulario enviado correctamente
        document.getElementById("formulario__mensaje-exito").classList.add("formulario__mensaje-exito-activo");
        //en 3 segundos desaparece el mensaje de correo enviado exitosamente
        setTimeout(() => {
            document.getElementById("formulario__mensaje-exito").classList.remove("formulario__mensaje-exito-activo");
        }, 3000);
        //elimino los iconos
        document.querySelectorAll(".fa-check-circle").forEach((icono) => {
            icono.classList.remove("fa-check-circle");
            icono.classList.add("formulario__validacion-estado");
        });

        formulario.reset();
    } else {
        document.getElementById("formulario__mensaje").classList.add("formulario__mensaje-activo");
        //en 3 segundos desaparece el mensaje de complete los campos correctamente
        setTimeout(() => {
            document.getElementById("formulario__mensaje").classList.remove("formulario__mensaje-activo");
        }, 3000);
    }
});
