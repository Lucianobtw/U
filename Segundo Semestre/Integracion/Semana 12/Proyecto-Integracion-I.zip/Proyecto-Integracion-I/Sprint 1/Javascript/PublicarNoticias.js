"use strict";

/* Funciones de Previsualizacion de contenido */

function pretitle() {
    let titlevalue = document.getElementById("titulo").value;
    let titulo = document.getElementById("pre-titulo");
    titulo.innerHTML = titlevalue;
}

function img() {
    let urlvalue = document.getElementById("url").value;
    let imagen = document.getElementById("pre-img");
    imagen.src = urlvalue;
}

function preautor() {
    let autorvalue = document.getElementById("autor").value;
    let autor = document.getElementById("pre-autor");
    autor.innerHTML = autorvalue;
}

function predescripcion() {
    let descvalue = document.getElementById("descripcion").value;
    let descripcion = document.getElementById("pre-desc");
    descripcion.innerHTML = descvalue;
}

/* ------------------------------------------------- */

//

/* Funcion Asincrona de publicación de Noticia */

let form = document.getElementById("p-formulario");

let insbtn = document.getElementById("publicar");

async function publicar(x) {
    const response = await fetch("./InsertaNoticias.php", {
        method: "POST",
        body: x,
    });

    const respuesta = await response.text();
}

form.addEventListener("submit", (e) => {
    e.preventDefault();
    let formData = new FormData(form);
    publicar(formData);
    form.reset();
});

/* ------------------------------------------------- */

//

/* Funcion que Cancela la publicacion de una Noticia */

let cancelbtn = document.getElementById("cancelar");

cancelbtn.addEventListener("click", () => {
    form.reset();
});

/* ------------------------------------------------- */
