CREATE TABLE contacto (
  ID INT(11) NOT NULL AUTO_INCREMENT,
  Primer_Nombre VARCHAR(25) NOT NULL,
  Primer_Apellido VARCHAR(25) NOT NULL,
  email VARCHAR(50) NOT NULL,
  Asunto VARCHAR(500) NOT NULL,
  PRIMARY KEY (ID)
);

INSERT INTO `contacto` (`ID`, `Primer_Nombre`, `Primer_Apellido`, `email`, `Asunto`) VALUES
(169, 'NIcolas', 'Ketterer', 'nketterer@uct.cl', 'Hola, soy un profesor'),
(171, 'como me llamo', 'llamo', 'tumamita200@gmail.co', 'hola me gustaria que me aiudaran con algo lo que pasa es que hay un problema de seguridad porque uno de los desarrolladores de esta pagina web me paso las credenciales de acceso a la base de datos por lo que mis datos e informaciÃ³n estan al descubierto de mi mismo :D'),
(172, 'Luciano', 'Revillod', 'lrevillod2022@alu.uct.cl', 'Hola soy un mensaje de prueba antes de entregar hola como estas luciano XD'),
(173, 'Luciano', 'Revillod', 'lr@r.com', 'Mensaje editado'),
(174, 'PATCH2', 'Perez', 'juan@nito.pz', 'Hola soy juanito'),
(175, 'EXPRESS', 'JS', 'express@js.js', 'Hpla esto es PUT'),
(177, 'alkjsd', 'aslkjd', 'naskjasd@alksdj.cl', 'alksjdalsdfj');

CREATE TABLE Usuarios (
  RUT int(11) NOT NULL,
  Username varchar(25) NOT NULL,
  email varchar(50) NOT NULL,
  password varchar(10000) NOT NULL,
  Admin int(11) NOT NULL,
  PRIMARY KEY (RUT)
);

INSERT INTO `Usuarios` (`RUT`, `Username`, `email`, `password`, `Admin`) VALUES
(21395308, 'MrRevillod', 'lrevillod2022@alu.uct.cl', 'bf2121ff91f6981ec3563732c5449209d504b6036a4d924e71dd4262d4eb770554f1641a20d72cf3b02cc8e914fc1ec36ef8a36b9e4092db0340b664cee6648f', 1),
(21568322, 'NIcoVZ', 'nvalenzuela2022@alu.uct.cl', 'bf2121ff91f6981ec3563732c5449209d504b6036a4d924e71dd4262d4eb770554f1641a20d72cf3b02cc8e914fc1ec36ef8a36b9e4092db0340b664cee6648f', 0);

/* https://expressjs-api-production.up.railway.app/ */