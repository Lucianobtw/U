Para ejecutar el servidor ExpressJS debe ejecutar dentro del directorio ExpressJS-API el comando "npm install" 
para instalar dependencias y luego "npm run dev" para arrancar el servidor

Para ejecutar la aplicación de ElectronJS debe ejecutar dentro del directorio APP ElectronJS "npm install"
 para instalar dependencias y luego "npm start" para arrancar la aplicación de escritorio

Credenciales = {
    "usuario": "MrRevillod",
    "contraseña": "contrasena"
}
