<?php

/* Es importante guardar la información de conexión en un archivo adicional */
/* Si se trabaja en un repositorio se puede ignorar el archivo mediante .gitignore */

$servername = "db.inf.uct.cl";
$username = "A2022_lrevillod";
$password = "A2022_lrevillod";
$dbname = "A2022_lrevillod";
